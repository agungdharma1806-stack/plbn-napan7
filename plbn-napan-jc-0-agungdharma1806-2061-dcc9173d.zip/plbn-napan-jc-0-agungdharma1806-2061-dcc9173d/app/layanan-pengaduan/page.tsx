import { MessageSquare, ExternalLink, Phone, Mail, FileText, AlertCircle, CheckCircle, Clock } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const complaintChannels = [
  {
    title: "SP4N LAPOR!",
    description: "Layanan Aspirasi dan Pengaduan Online Rakyat - Kanal resmi pengaduan pemerintah Indonesia",
    icon: "🏛️",
    href: "https://www.lapor.go.id",
    buttonText: "Buka LAPOR!",
    color: "bg-red-500",
    features: ["Terintegrasi nasional", "Terpantau instansi terkait", "Respon terukur"],
  },
  {
    title: "WhatsApp Pengaduan",
    description: "Sampaikan pengaduan langsung melalui WhatsApp resmi PLBN Napan",
    icon: "💬",
    href: "https://wa.me/6281234567890?text=Halo%20PLBN%20Napan%2C%20saya%20ingin%20menyampaikan%20pengaduan%3A",
    buttonText: "Chat WhatsApp",
    color: "bg-green-500",
    features: ["Respon cepat", "Mudah digunakan", "Terdokumentasi"],
  },
  {
    title: "Email Pengaduan",
    description: "Kirim pengaduan tertulis melalui email resmi PLBN Napan",
    icon: "📧",
    href: "mailto:pengaduan.plbn.napan@bnpp.go.id?subject=Pengaduan%20Layanan%20PLBN%20Napan",
    buttonText: "Kirim Email",
    color: "bg-blue-500",
    features: ["Formal", "Dapat dilampiri dokumen", "Tercatat resmi"],
  },
  {
    title: "Google Form",
    description: "Isi formulir pengaduan online untuk pencatatan yang lebih terstruktur",
    icon: "📝",
    href: "https://forms.google.com",
    buttonText: "Isi Formulir",
    color: "bg-purple-500",
    features: ["Terstruktur", "Anonim opsional", "Mudah dilacak"],
  },
]

const hotlines = [
  {
    title: "Telepon Kantor",
    number: "(0388) 21234",
    description: "Senin - Jumat, 08.00 - 16.00 WITA",
    icon: Phone,
  },
  {
    title: "Email Resmi",
    number: "plbn.napan@bnpp.go.id",
    description: "Respon dalam 1x24 jam kerja",
    icon: Mail,
  },
]

const complaintSteps = [
  {
    step: 1,
    title: "Pilih Kanal Pengaduan",
    description: "Pilih salah satu kanal pengaduan yang tersedia sesuai preferensi Anda",
  },
  {
    step: 2,
    title: "Sampaikan Pengaduan",
    description: "Tuliskan pengaduan dengan jelas, sertakan identitas dan kronologi kejadian",
  },
  {
    step: 3,
    title: "Tunggu Verifikasi",
    description: "Tim kami akan memverifikasi dan meneruskan pengaduan ke unit terkait",
  },
  {
    step: 4,
    title: "Tindak Lanjut",
    description: "Anda akan mendapat informasi tindak lanjut melalui kanal yang sama",
  },
]

export default function LayananPengaduanPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Page Header */}
        <section className="bg-gradient-to-br from-primary to-accent py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center text-primary-foreground">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6">
                <MessageSquare className="h-8 w-8" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Layanan Pengaduan
              </h1>
              <p className="text-lg text-primary-foreground/90">
                Sampaikan keluhan, saran, atau masukan Anda untuk peningkatan kualitas pelayanan di PLBN Napan
              </p>
            </div>
          </div>
        </section>

        {/* Complaint Channels */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                Kanal Pengaduan
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Pilih kanal pengaduan yang paling sesuai dengan kebutuhan Anda
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
              {complaintChannels.map((channel, index) => (
                <Card 
                  key={index} 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-start gap-4">
                      <div className={`flex items-center justify-center w-14 h-14 rounded-xl ${channel.color} text-2xl`}>
                        {channel.icon}
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{channel.title}</CardTitle>
                        <CardDescription className="mt-1">
                          {channel.description}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex flex-wrap gap-2">
                      {channel.features.map((feature, fIndex) => (
                        <span 
                          key={fIndex}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-muted text-xs text-muted-foreground"
                        >
                          <CheckCircle className="h-3 w-3" />
                          {feature}
                        </span>
                      ))}
                    </div>
                    <Button asChild className="w-full group">
                      <a href={channel.href} target="_blank" rel="noopener noreferrer">
                        {channel.buttonText}
                        <ExternalLink className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Hotlines */}
        <section className="py-12 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-xl font-bold mb-2">Kontak Langsung</h2>
                <p className="text-primary-foreground/80 text-sm">
                  Hubungi kami langsung untuk informasi atau pengaduan mendesak
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {hotlines.map((hotline, index) => (
                  <div 
                    key={index}
                    className="flex items-center gap-4 bg-white/10 rounded-xl p-4 backdrop-blur"
                  >
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-white/10">
                      <hotline.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-primary-foreground/70">{hotline.title}</p>
                      <p className="font-semibold">{hotline.number}</p>
                      <p className="text-xs text-primary-foreground/60">{hotline.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Complaint Steps */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                Alur Pengaduan
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Langkah-langkah menyampaikan pengaduan di PLBN Napan
              </p>
            </div>

            <div className="max-w-4xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {complaintSteps.map((item, index) => (
                  <div key={index} className="relative">
                    {/* Connector Line */}
                    {index < complaintSteps.length - 1 && (
                      <div className="hidden md:block absolute top-8 left-1/2 w-full h-0.5 bg-border" />
                    )}
                    <div className="relative flex flex-col items-center text-center">
                      <div className="flex items-center justify-center w-16 h-16 rounded-full bg-primary text-primary-foreground font-bold text-xl mb-4 z-10">
                        {item.step}
                      </div>
                      <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Important Notes */}
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <Card className="border-amber-200 bg-amber-50/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <AlertCircle className="h-6 w-6 text-amber-600" />
                    <CardTitle className="text-amber-800">Informasi Penting</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 text-amber-900">
                  <div className="flex items-start gap-3">
                    <FileText className="h-5 w-5 shrink-0 mt-0.5" />
                    <p className="text-sm">
                      Pengaduan yang efektif harus mencakup: identitas pelapor, waktu dan lokasi kejadian, 
                      kronologi singkat, dan bukti pendukung (jika ada).
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 shrink-0 mt-0.5" />
                    <p className="text-sm">
                      Waktu penyelesaian pengaduan maksimal 14 hari kerja sejak pengaduan diterima dan 
                      diverifikasi lengkap.
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 shrink-0 mt-0.5" />
                    <p className="text-sm">
                      Identitas pelapor dijamin kerahasiaannya sesuai dengan ketentuan peraturan 
                      perundang-undangan yang berlaku.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
