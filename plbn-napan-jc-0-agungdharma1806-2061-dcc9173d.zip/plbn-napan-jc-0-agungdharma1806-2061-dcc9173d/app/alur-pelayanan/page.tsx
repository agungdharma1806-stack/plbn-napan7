"use client"

import { useState } from "react"
import Image from "next/image"
import { GitBranch, ZoomIn, ArrowRight, Plane, PlaneLanding, Clock, CheckCircle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Lightbox } from "@/components/lightbox"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

const serviceFlows = [
  {
    id: "kedatangan",
    title: "Alur Kedatangan",
    subtitle: "Dari Timor Leste ke Indonesia",
    icon: PlaneLanding,
    description: "Prosedur pelayanan bagi pelintas yang memasuki wilayah Indonesia melalui PLBN Napan",
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Salinan%20dari%20Prosedur%20dan%20SP%20PLBN%20Napan-WkCJ2ExWfs1qMib12orgsPVOGqI0Yt.png",
    steps: [
      { title: "Memasuki Ruang Pelayanan Kedatangan", description: "Pelintas memasuki area kedatangan PLBN Napan" },
      { title: "Counter Pelayanan Karantina Kesehatan", description: "Pemeriksaan kesehatan dan dokumen OMKABA jika diperlukan" },
      { title: "Counter Pelayanan Imigrasi", description: "Pemeriksaan paspor dan dokumen perjalanan" },
      { title: "Pemeriksaan Barang di Counter Bea Cukai", description: "Pemeriksaan barang bawaan melalui X-Ray" },
      { title: "Counter Pelayanan Karantina Hewan & Tumbuhan", description: "Pemeriksaan produk hewan, ikan, dan tumbuhan" },
      { title: "Memasuki Wilayah Indonesia", description: "Pelintas resmi memasuki wilayah NKRI" },
    ],
  },
  {
    id: "keberangkatan",
    title: "Alur Keberangkatan",
    subtitle: "Dari Indonesia ke Timor Leste",
    icon: Plane,
    description: "Prosedur pelayanan bagi pelintas yang keluar dari wilayah Indonesia melalui PLBN Napan",
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Salinan%20dari%20Prosedur%20dan%20SP%20PLBN%20Napan%20%281%29-qBF4YU1zQo0GTaEVPiIuGz0fprMhn9.png",
    steps: [
      { title: "Memasuki Ruang Pelayanan Keberangkatan", description: "Pelintas memasuki area keberangkatan PLBN Napan" },
      { title: "Counter Pelayanan Imigrasi", description: "Pemeriksaan paspor dan dokumen perjalanan" },
      { title: "Counter Pelayanan Karantina Hewan & Tumbuhan", description: "Pemeriksaan produk hewan, ikan, dan tumbuhan" },
      { title: "Pemeriksaan Barang di Counter Bea Cukai", description: "Pemeriksaan barang bawaan melalui X-Ray" },
      { title: "Counter Pelayanan Karantina Kesehatan", description: "Pemeriksaan kesehatan jika diperlukan" },
      { title: "Berangkat Menuju Timor Leste", description: "Pelintas resmi keluar dari wilayah NKRI" },
    ],
  },
]

const serviceInfo = [
  {
    title: "Pelayanan Imigrasi",
    requirements: "Paspor/Pas Pelintas yang masih berlaku",
    time: "5-10 menit",
    cost: "GRATIS (overstay dikenakan denda)",
  },
  {
    title: "Pelayanan Bea Cukai",
    requirements: "Pemeriksaan barang bawaan melalui X-Ray",
    time: "3-5 menit",
    cost: "GRATIS",
  },
  {
    title: "Pelayanan Karantina Kesehatan",
    requirements: "Pengawasan suhu tubuh, pemeriksaan kendaraan",
    time: "5-10 menit",
    cost: "GRATIS (PNBP untuk vaksinasi)",
  },
  {
    title: "Pelayanan BKHIT",
    requirements: "Sertifikat kesehatan hewan/tumbuhan, Import permit",
    time: "5-10 menit",
    cost: "Sesuai Peraturan Menteri Keuangan",
  },
]

export default function AlurPelayananPage() {
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [currentFlowIndex, setCurrentFlowIndex] = useState(0)

  const allImages = serviceFlows.map(flow => ({
    src: flow.imageSrc,
    alt: flow.title
  }))

  const handleImageClick = (index: number) => {
    setCurrentFlowIndex(index)
    setLightboxOpen(true)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Page Header */}
        <section className="bg-gradient-to-br from-primary to-accent py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center text-primary-foreground">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6">
                <GitBranch className="h-8 w-8" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Alur Pelayanan
              </h1>
              <p className="text-lg text-primary-foreground/90">
                Panduan lengkap alur pelayanan perlintasan batas di PLBN Napan untuk kedatangan dan keberangkatan
              </p>
            </div>
          </div>
        </section>

        {/* Flow Tabs */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="kedatangan" className="space-y-8">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
                <TabsTrigger value="kedatangan" className="gap-2">
                  <PlaneLanding className="h-4 w-4" />
                  Kedatangan
                </TabsTrigger>
                <TabsTrigger value="keberangkatan" className="gap-2">
                  <Plane className="h-4 w-4" />
                  Keberangkatan
                </TabsTrigger>
              </TabsList>

              {serviceFlows.map((flow, flowIndex) => (
                <TabsContent key={flow.id} value={flow.id} className="space-y-8">
                  {/* Flow Card */}
                  <div className="grid lg:grid-cols-2 gap-8">
                    {/* Image */}
                    <div 
                      className="group relative bg-card rounded-2xl overflow-hidden shadow-lg border border-border/50 cursor-pointer transition-all duration-300 hover:shadow-xl"
                      onClick={() => handleImageClick(flowIndex)}
                    >
                      <div className="relative aspect-[3/4] lg:aspect-auto lg:h-full min-h-[400px]">
                        <Image
                          src={flow.imageSrc}
                          alt={flow.title}
                          fill
                          className="object-contain bg-white p-2"
                        />
                        {/* Overlay */}
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center">
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center gap-2 px-6 py-3 rounded-full bg-white text-primary font-medium shadow-lg">
                            <ZoomIn className="h-5 w-5" />
                            <span>Klik untuk memperbesar</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Steps */}
                    <div className="space-y-6">
                      <div>
                        <h2 className="text-2xl font-bold text-foreground mb-2">{flow.title}</h2>
                        <p className="text-muted-foreground">{flow.description}</p>
                      </div>

                      <div className="space-y-4">
                        {flow.steps.map((step, stepIndex) => (
                          <div 
                            key={stepIndex}
                            className="flex gap-4 animate-fadeIn"
                            style={{ animationDelay: `${stepIndex * 100}ms` }}
                          >
                            <div className="flex flex-col items-center">
                              <div className={cn(
                                "flex items-center justify-center w-10 h-10 rounded-full text-sm font-semibold",
                                stepIndex === flow.steps.length - 1 
                                  ? "bg-green-500 text-white" 
                                  : "bg-primary text-primary-foreground"
                              )}>
                                {stepIndex === flow.steps.length - 1 ? (
                                  <CheckCircle className="h-5 w-5" />
                                ) : (
                                  stepIndex + 1
                                )}
                              </div>
                              {stepIndex < flow.steps.length - 1 && (
                                <div className="w-0.5 h-full min-h-[20px] bg-border mt-2" />
                              )}
                            </div>
                            <div className="flex-1 pb-4">
                              <h4 className="font-semibold text-foreground">{step.title}</h4>
                              <p className="text-sm text-muted-foreground mt-1">{step.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      <Button 
                        size="lg" 
                        className="w-full sm:w-auto"
                        onClick={() => handleImageClick(flowIndex)}
                      >
                        <ZoomIn className="h-4 w-4 mr-2" />
                        Lihat Infografis Lengkap
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>

        {/* Service Info Cards */}
        <section className="py-12 md:py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                Informasi Layanan
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Detail persyaratan, waktu pelayanan, dan biaya untuk setiap jenis layanan di PLBN Napan
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {serviceInfo.map((service, index) => (
                <Card 
                  key={index} 
                  className="bg-card hover:shadow-md transition-shadow animate-fadeIn"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base text-primary">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Persyaratan</p>
                      <p className="text-sm">{service.requirements}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{service.time}</span>
                    </div>
                    <div className="pt-2 border-t">
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Biaya</p>
                      <p className="text-sm font-medium text-green-600">{service.cost}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Tips Section */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <Card className="bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-primary">Tips Perlintasan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-sm">Pastikan semua dokumen perjalanan masih berlaku sebelum melakukan perlintasan</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-sm">Siapkan dokumen tambahan seperti sertifikat kesehatan hewan/tumbuhan jika membawa produk tersebut</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-sm">Datang lebih awal untuk menghindari antrian panjang terutama pada jam sibuk</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-sm">Patuhi semua instruksi petugas dan prosedur yang berlaku</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Lightbox */}
      <Lightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        imageSrc={allImages[currentFlowIndex]?.src || ""}
        imageAlt={allImages[currentFlowIndex]?.alt || ""}
        images={allImages}
        currentIndex={currentFlowIndex}
        onNavigate={setCurrentFlowIndex}
      />
    </div>
  )
}
