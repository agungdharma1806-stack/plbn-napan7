import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Twitter, Youtube, ExternalLink, Navigation } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const contactInfo = [
  {
    icon: MapPin,
    title: "Alamat Kantor",
    content: "Desa Napan, Kecamatan Bikomi Utara",
    subcontent: "Kabupaten Timor Tengah Utara, Nusa Tenggara Timur",
    action: {
      label: "Lihat di Maps",
      href: "https://maps.google.com/?q=PLBN+Napan+TTU",
    },
  },
  {
    icon: Phone,
    title: "Telepon",
    content: "(0388) 21234",
    subcontent: "Senin - Jumat, 08.00 - 16.00 WITA",
    action: {
      label: "Hubungi",
      href: "tel:+6238821234",
    },
  },
  {
    icon: Mail,
    title: "Email",
    content: "plbn.napan@bnpp.go.id",
    subcontent: "Respon dalam 1x24 jam kerja",
    action: {
      label: "Kirim Email",
      href: "mailto:plbn.napan@bnpp.go.id",
    },
  },
  {
    icon: Clock,
    title: "Jam Operasional",
    content: "07.00 - 21.00 WITA",
    subcontent: "Setiap Hari (Senin - Minggu)",
    action: null,
  },
]

const socialMedia = [
  { 
    icon: Facebook, 
    name: "Facebook", 
    handle: "@PLBNNapan", 
    href: "#",
    color: "bg-blue-600 hover:bg-blue-700"
  },
  { 
    icon: Instagram, 
    name: "Instagram", 
    handle: "@plbn_napan", 
    href: "#",
    color: "bg-gradient-to-br from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
  },
  { 
    icon: Twitter, 
    name: "Twitter/X", 
    handle: "@PLBNNapan", 
    href: "#",
    color: "bg-gray-900 hover:bg-gray-800"
  },
  { 
    icon: Youtube, 
    name: "YouTube", 
    handle: "PLBN Napan Official", 
    href: "#",
    color: "bg-red-600 hover:bg-red-700"
  },
]

const relatedAgencies = [
  {
    name: "Badan Nasional Pengelola Perbatasan (BNPP)",
    website: "https://www.bnpp.go.id",
    description: "Lembaga pemerintah yang mengelola perbatasan negara",
  },
  {
    name: "Direktorat Jenderal Imigrasi",
    website: "https://www.imigrasi.go.id",
    description: "Pelayanan keimigrasian dan dokumen perjalanan",
  },
  {
    name: "Direktorat Jenderal Bea dan Cukai",
    website: "https://www.beacukai.go.id",
    description: "Pengawasan kepabeanan dan cukai",
  },
  {
    name: "Badan Karantina Indonesia",
    website: "https://karantina.pertanian.go.id",
    description: "Pelayanan karantina hewan, ikan, dan tumbuhan",
  },
]

export default function KontakPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Page Header */}
        <section className="bg-gradient-to-br from-primary to-accent py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center text-primary-foreground">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6">
                <Phone className="h-8 w-8" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Hubungi Kami
              </h1>
              <p className="text-lg text-primary-foreground/90">
                Informasi kontak lengkap PLBN Napan untuk pertanyaan dan informasi seputar pelayanan
              </p>
            </div>
          </div>
        </section>

        {/* Contact Cards */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {contactInfo.map((item, index) => (
                <Card 
                  key={index} 
                  className="text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <CardHeader className="pb-3">
                    <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 text-primary mx-auto mb-3">
                      <item.icon className="h-7 w-7" />
                    </div>
                    <CardTitle className="text-base">{item.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="font-semibold text-foreground">{item.content}</p>
                    <p className="text-sm text-muted-foreground">{item.subcontent}</p>
                    {item.action && (
                      <Button asChild variant="outline" size="sm" className="mt-3">
                        <a href={item.action.href} target="_blank" rel="noopener noreferrer">
                          {item.action.label}
                          <ExternalLink className="ml-2 h-3 w-3" />
                        </a>
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-foreground mb-3">Lokasi Kami</h2>
                <p className="text-muted-foreground">
                  PLBN Napan terletak di perbatasan Indonesia - Timor Leste, Kabupaten Timor Tengah Utara
                </p>
              </div>
              
              <Card className="overflow-hidden">
                <div className="aspect-video bg-muted relative">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3941.0!2d124.5!3d-9.3!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zOcKwMTgnMDAuMCJTIDEyNMKwMzAnMDAuMCJF!5e0!3m2!1sen!2sid!4v1620000000000!5m2!1sen!2sid"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="absolute inset-0"
                    title="Lokasi PLBN Napan"
                  />
                  {/* Fallback overlay if map doesn't load */}
                  <div className="absolute inset-0 flex items-center justify-center bg-muted/80 pointer-events-none opacity-0 hover:opacity-0">
                    <div className="text-center">
                      <Navigation className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                      <p className="text-muted-foreground">Peta Lokasi PLBN Napan</p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-4 bg-card">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">PLBN Napan</p>
                        <p className="text-sm text-muted-foreground">
                          Desa Napan, Kec. Bikomi Utara, Kab. TTU, NTT
                        </p>
                      </div>
                    </div>
                    <Button asChild>
                      <a 
                        href="https://maps.google.com/?q=PLBN+Napan+TTU" 
                        target="_blank" 
                        rel="noopener noreferrer"
                      >
                        <Navigation className="mr-2 h-4 w-4" />
                        Petunjuk Arah
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Social Media */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                Media Sosial
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Ikuti media sosial resmi PLBN Napan untuk informasi terbaru
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
              {socialMedia.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex flex-col items-center gap-3 p-6 rounded-xl text-white transition-all duration-300 hover:scale-105 hover:shadow-lg ${social.color}`}
                >
                  <social.icon className="h-8 w-8" />
                  <div className="text-center">
                    <p className="font-semibold text-sm">{social.name}</p>
                    <p className="text-xs opacity-80">{social.handle}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* Related Agencies */}
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                Instansi Terkait
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Tautan ke website instansi terkait pelayanan di PLBN Napan
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
              {relatedAgencies.map((agency, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground mb-1">{agency.name}</h3>
                        <p className="text-sm text-muted-foreground">{agency.description}</p>
                      </div>
                      <Button asChild variant="ghost" size="icon" className="shrink-0">
                        <a href={agency.website} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                          <span className="sr-only">Kunjungi {agency.name}</span>
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
