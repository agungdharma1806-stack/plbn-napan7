"use client"

import { useState } from "react"
import Image from "next/image"
import { FileText, ZoomIn, Download, ExternalLink } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Lightbox } from "@/components/lightbox"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const sopDocuments = [
  {
    id: 1,
    title: "SOP Prosedur Perlintasan Orang di Terminal Kedatangan",
    description: "Standar operasional prosedur untuk pelayanan perlintasan orang yang datang dari Timor Leste ke Indonesia melalui PLBN Napan",
    category: "Kedatangan",
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-05-09%20at%2022.36.26-lauAmzoSTXDqcNCIwJnyHN8avWjDiB.jpeg",
  },
  {
    id: 2,
    title: "SOP Prosedur Perlintasan Orang di Terminal Keberangkatan",
    description: "Standar operasional prosedur untuk pelayanan perlintasan orang yang berangkat dari Indonesia ke Timor Leste melalui PLBN Napan",
    category: "Keberangkatan",
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-05-09%20at%2021.01.44-PsOX8rhtknbxNvhcTrjgIkuauAhQfZ.jpeg",
  },
  {
    id: 3,
    title: "SOP Kunjungan Wisatawan PLBN Napan",
    description: "Standar operasional prosedur untuk penerimaan kunjungan wisatawan di kawasan PLBN Napan",
    category: "Wisatawan",
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Biru%20Kuning%20Ilustrasi%20Tips%20Produktivitas%20Kerja%20Instagram%20Post%20%28Konten%20Instagram%20%2845%29%29%20%284%29-exDq9cXDCxnTGh8ZxZZH6VG3hrYM1U.png",
  },
]

const categories = ["Semua", "Kedatangan", "Keberangkatan", "Wisatawan"]

export default function StandarOperasionalPage() {
  const [selectedCategory, setSelectedCategory] = useState("Semua")
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const filteredDocuments = selectedCategory === "Semua" 
    ? sopDocuments 
    : sopDocuments.filter(doc => doc.category === selectedCategory)

  const allImages = sopDocuments.map(doc => ({
    src: doc.imageSrc,
    alt: doc.title
  }))

  const handleImageClick = (index: number) => {
    const globalIndex = sopDocuments.findIndex(doc => doc.id === filteredDocuments[index].id)
    setCurrentImageIndex(globalIndex)
    setLightboxOpen(true)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Page Header */}
        <section className="bg-gradient-to-br from-primary to-accent py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center text-primary-foreground">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6">
                <FileText className="h-8 w-8" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Standar Operasional Prosedur
              </h1>
              <p className="text-lg text-primary-foreground/90">
                Dokumen SOP pelayanan di PLBN Napan untuk memastikan pelayanan yang transparan dan terstandar
              </p>
            </div>
          </div>
        </section>

        {/* Filter Categories */}
        <section className="py-8 border-b">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap items-center justify-center gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={cn(
                    "transition-all duration-200",
                    selectedCategory === category && "shadow-md"
                  )}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* SOP Documents Grid */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDocuments.map((doc, index) => (
                <div
                  key={doc.id}
                  className="group bg-card rounded-xl overflow-hidden shadow-md border border-border/50 transition-all duration-300 hover:shadow-xl hover:border-primary/30 hover:-translate-y-1 animate-fadeIn"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {/* Image Container */}
                  <div 
                    className="relative aspect-[3/4] overflow-hidden cursor-pointer"
                    onClick={() => handleImageClick(index)}
                  >
                    <Image
                      src={doc.imageSrc}
                      alt={doc.title}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/95 text-primary font-medium text-sm shadow-lg">
                        <ZoomIn className="h-4 w-4" />
                        <span>Lihat Detail</span>
                      </div>
                    </div>
                    {/* Category Badge */}
                    <div className="absolute top-3 left-3">
                      <span className="px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-medium shadow">
                        {doc.category}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    <h3 className="font-semibold text-base text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                      {doc.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-3 mb-4">
                      {doc.description}
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => handleImageClick(index)}
                    >
                      <ZoomIn className="h-4 w-4 mr-2" />
                      Buka Gambar
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {filteredDocuments.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Tidak ada dokumen SOP untuk kategori ini.</p>
              </div>
            )}
          </div>
        </section>

        {/* Info Section */}
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-xl font-semibold mb-4">Informasi Penting</h2>
              <p className="text-muted-foreground mb-6">
                Dokumen SOP ini merupakan panduan resmi pelayanan di PLBN Napan. Klik pada gambar untuk memperbesar dan gunakan fitur zoom untuk membaca detail dokumen.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <ZoomIn className="h-4 w-4" />
                  <span>Klik gambar untuk zoom</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <ExternalLink className="h-4 w-4" />
                  <span>Scroll untuk zoom dalam lightbox</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Lightbox */}
      <Lightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        imageSrc={allImages[currentImageIndex]?.src || ""}
        imageAlt={allImages[currentImageIndex]?.alt || ""}
        images={allImages}
        currentIndex={currentImageIndex}
        onNavigate={setCurrentImageIndex}
      />
    </div>
  )
}
