import Link from "next/link"
import { ArrowRight, FileText, GitBranch, MessageSquare, Phone, Clock, MapPin, Users } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { HeroBanner } from "@/components/hero-banner"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const services = [
  {
    icon: FileText,
    title: "Standar Operasional",
    description: "Lihat prosedur dan standar operasional pelayanan di PLBN Napan",
    href: "/standar-operasional",
    color: "bg-blue-500",
  },
  {
    icon: GitBranch,
    title: "Alur Pelayanan",
    description: "Panduan alur pelayanan perlintasan batas untuk kedatangan dan keberangkatan",
    href: "/alur-pelayanan",
    color: "bg-emerald-500",
  },
  {
    icon: MessageSquare,
    title: "Layanan Pengaduan",
    description: "Sampaikan keluhan atau masukan Anda untuk peningkatan pelayanan",
    href: "/layanan-pengaduan",
    color: "bg-amber-500",
  },
  {
    icon: Phone,
    title: "Kontak Kami",
    description: "Hubungi kami untuk informasi lebih lanjut seputar pelayanan",
    href: "/kontak",
    color: "bg-rose-500",
  },
]

const stats = [
  { icon: Users, value: "1000+", label: "Pelintasan/Bulan" },
  { icon: Clock, value: "24/7", label: "Operasional" },
  { icon: MapPin, value: "TTU", label: "Lokasi" },
]

const announcements = [
  {
    title: "Jam Operasional PLBN Napan",
    description: "PLBN Napan beroperasi setiap hari pukul 07.00 - 21.00 WITA untuk pelayanan perlintasan reguler.",
    date: "Pengumuman",
  },
  {
    title: "Persyaratan Perlintasan",
    description: "Pastikan membawa dokumen yang diperlukan: Paspor/Pas Pelintas, dokumen perjalanan yang masih berlaku.",
    date: "Informasi",
  },
  {
    title: "Zona Inti PLBN Napan",
    description: "Jam berkunjung di Zona Inti pukul 13.00 - 17.00 WITA setiap hari Senin - Minggu.",
    date: "Pengumuman",
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Banner */}
        <HeroBanner />

        {/* Quick Services */}
        <section className="py-16 md:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                Layanan Kami
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                PLBN Napan menyediakan berbagai layanan untuk memudahkan proses perlintasan batas negara
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {services.map((service, index) => (
                <Link key={index} href={service.href} className="group">
                  <Card className="h-full transition-all duration-300 hover:shadow-lg hover:-translate-y-1 hover:border-primary/30">
                    <CardHeader>
                      <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg ${service.color} text-white mb-2`}>
                        <service.icon className="h-6 w-6" />
                      </div>
                      <CardTitle className="text-lg group-hover:text-primary transition-colors">
                        {service.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-sm">
                        {service.description}
                      </CardDescription>
                      <div className="flex items-center mt-4 text-primary text-sm font-medium">
                        Selengkapnya
                        <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 bg-primary">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-3 gap-8 max-w-3xl mx-auto">
              {stats.map((stat, index) => (
                <div key={index} className="text-center text-primary-foreground">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-white/10 mb-3">
                    <stat.icon className="h-6 w-6" />
                  </div>
                  <div className="text-2xl md:text-3xl font-bold">{stat.value}</div>
                  <div className="text-sm text-primary-foreground/80">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Announcements */}
        <section className="py-16 md:py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                Pengumuman & Informasi
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Informasi terbaru seputar pelayanan di PLBN Napan
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {announcements.map((item, index) => (
                <Card key={index} className="bg-card hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-2 w-fit">
                      {item.date}
                    </div>
                    <CardTitle className="text-base">{item.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-sm">
                      {item.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center bg-gradient-to-br from-primary to-accent rounded-2xl p-8 md:p-12 text-primary-foreground">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                Butuh Bantuan atau Informasi?
              </h2>
              <p className="text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
                Tim PLBN Napan siap membantu Anda. Hubungi kami atau sampaikan pengaduan melalui kanal yang tersedia.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                  <Link href="/layanan-pengaduan">
                    <MessageSquare className="mr-2 h-5 w-5" />
                    Layanan Pengaduan
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 hover:text-white">
                  <Link href="/kontak">
                    <Phone className="mr-2 h-5 w-5" />
                    Hubungi Kami
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
