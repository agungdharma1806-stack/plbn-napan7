"use client"

import { useState, useEffect, useCallback } from "react"
import Image from "next/image"
import { X, ZoomIn, ZoomOut, RotateCw, Download, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface LightboxProps {
  isOpen: boolean
  onClose: () => void
  imageSrc: string
  imageAlt: string
  images?: { src: string; alt: string }[]
  currentIndex?: number
  onNavigate?: (index: number) => void
}

export function Lightbox({ 
  isOpen, 
  onClose, 
  imageSrc, 
  imageAlt,
  images,
  currentIndex = 0,
  onNavigate
}: LightboxProps) {
  const [zoom, setZoom] = useState(1)
  const [rotation, setRotation] = useState(0)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })

  const resetView = useCallback(() => {
    setZoom(1)
    setRotation(0)
    setPosition({ x: 0, y: 0 })
  }, [])

  useEffect(() => {
    if (!isOpen) {
      resetView()
    }
  }, [isOpen, resetView])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return
      
      switch (e.key) {
        case "Escape":
          onClose()
          break
        case "+":
        case "=":
          setZoom(z => Math.min(z + 0.25, 4))
          break
        case "-":
          setZoom(z => Math.max(z - 0.25, 0.5))
          break
        case "ArrowLeft":
          if (images && onNavigate && currentIndex > 0) {
            onNavigate(currentIndex - 1)
            resetView()
          }
          break
        case "ArrowRight":
          if (images && onNavigate && currentIndex < images.length - 1) {
            onNavigate(currentIndex + 1)
            resetView()
          }
          break
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isOpen, onClose, images, onNavigate, currentIndex, resetView])

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? -0.1 : 0.1
    setZoom(z => Math.min(Math.max(z + delta, 0.5), 4))
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoom > 1) {
      setIsDragging(true)
      setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y })
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  if (!isOpen) return null

  const displayImage = images ? images[currentIndex] : { src: imageSrc, alt: imageAlt }
  const hasMultipleImages = images && images.length > 1

  return (
    <div 
      className="fixed inset-0 z-[100] bg-black/95 flex flex-col"
      onClick={handleBackdropClick}
    >
      {/* Header Controls */}
      <div className="flex items-center justify-between p-4 bg-black/50">
        <div className="text-white text-sm">
          {hasMultipleImages && (
            <span>{currentIndex + 1} / {images.length}</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={() => setZoom(z => Math.min(z + 0.25, 4))}
          >
            <ZoomIn className="h-5 w-5" />
            <span className="sr-only">Perbesar</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={() => setZoom(z => Math.max(z - 0.25, 0.5))}
          >
            <ZoomOut className="h-5 w-5" />
            <span className="sr-only">Perkecil</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={() => setRotation(r => r + 90)}
          >
            <RotateCw className="h-5 w-5" />
            <span className="sr-only">Putar</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={resetView}
          >
            <span className="text-xs font-medium">Reset</span>
          </Button>
          <div className="w-px h-6 bg-white/30 mx-2" />
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
            <span className="sr-only">Tutup</span>
          </Button>
        </div>
      </div>

      {/* Image Container */}
      <div 
        className="flex-1 flex items-center justify-center overflow-hidden relative"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Navigation Arrows */}
        {hasMultipleImages && (
          <>
            <Button
              variant="ghost"
              size="icon"
              className={cn(
                "absolute left-4 z-10 text-white hover:bg-white/20 h-12 w-12",
                currentIndex === 0 && "opacity-50 cursor-not-allowed"
              )}
              onClick={() => {
                if (currentIndex > 0 && onNavigate) {
                  onNavigate(currentIndex - 1)
                  resetView()
                }
              }}
              disabled={currentIndex === 0}
            >
              <ChevronLeft className="h-8 w-8" />
              <span className="sr-only">Sebelumnya</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={cn(
                "absolute right-4 z-10 text-white hover:bg-white/20 h-12 w-12",
                currentIndex === images.length - 1 && "opacity-50 cursor-not-allowed"
              )}
              onClick={() => {
                if (currentIndex < images.length - 1 && onNavigate) {
                  onNavigate(currentIndex + 1)
                  resetView()
                }
              }}
              disabled={currentIndex === images.length - 1}
            >
              <ChevronRight className="h-8 w-8" />
              <span className="sr-only">Berikutnya</span>
            </Button>
          </>
        )}

        {/* Image */}
        <div
          className={cn(
            "relative transition-transform duration-200",
            isDragging && "cursor-grabbing",
            zoom > 1 && !isDragging && "cursor-grab"
          )}
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${zoom}) rotate(${rotation}deg)`,
          }}
        >
          <Image
            src={displayImage.src}
            alt={displayImage.alt}
            width={1200}
            height={900}
            className="max-h-[85vh] w-auto object-contain select-none"
            draggable={false}
            priority
          />
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-4 bg-black/50 text-center">
        <p className="text-white text-sm">{displayImage.alt}</p>
        <p className="text-white/60 text-xs mt-1">
          Zoom: {Math.round(zoom * 100)}% | Gunakan scroll mouse atau tombol +/- untuk zoom
        </p>
      </div>
    </div>
  )
}
