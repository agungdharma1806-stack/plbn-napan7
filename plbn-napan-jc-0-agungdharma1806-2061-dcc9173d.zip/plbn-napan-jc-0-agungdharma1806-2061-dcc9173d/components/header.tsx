"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, Shield } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet"

const navItems = [
  { href: "/", label: "Beranda" },
  { href: "/standar-operasional", label: "Standar Operasional" },
  { href: "/alur-pelayanan", label: "Alur Pelayanan" },
  { href: "/layanan-pengaduan", label: "Layanan Pengaduan" },
  { href: "/kontak", label: "Kontak" },
]

export function Header() {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between md:h-20">
          {/* Logo and Title */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md transition-transform group-hover:scale-105">
              <Shield className="h-5 w-5 md:h-6 md:w-6" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm md:text-lg font-bold text-primary leading-tight">
                PLBN NAPAN
              </span>
              <span className="text-[10px] md:text-xs text-muted-foreground leading-tight">
                Pos Lintas Batas Negara
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-md transition-all duration-200",
                  "hover:bg-primary/10 hover:text-primary",
                  pathname === item.href
                    ? "bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground"
                    : "text-foreground/80"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Mobile Navigation */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon" className="h-10 w-10">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Menu Navigasi</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] sm:w-[350px] p-0">
              <SheetTitle className="sr-only">Menu Navigasi</SheetTitle>
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      <Shield className="h-5 w-5" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-primary">PLBN NAPAN</span>
                      <span className="text-[10px] text-muted-foreground">Pos Lintas Batas Negara</span>
                    </div>
                  </div>
                </div>
                <nav className="flex flex-col p-4 gap-1">
                  {navItems.map((item, index) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={cn(
                        "px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 animate-slideIn",
                        "hover:bg-primary/10 hover:text-primary",
                        pathname === item.href
                          ? "bg-primary text-primary-foreground"
                          : "text-foreground/80"
                      )}
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      {item.label}
                    </Link>
                  ))}
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
