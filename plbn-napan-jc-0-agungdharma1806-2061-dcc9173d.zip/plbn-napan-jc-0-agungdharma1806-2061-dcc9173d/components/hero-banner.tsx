"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowRight, Clock, FileText, Users, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const features = [
  {
    icon: Clock,
    title: "Operasional 24 Jam",
    description: "Layanan perlintasan batas tersedia setiap hari",
  },
  {
    icon: FileText,
    title: "Prosedur Jelas",
    description: "SOP terintegrasi untuk pelayanan optimal",
  },
  {
    icon: Users,
    title: "Pelayanan Prima",
    description: "Petugas profesional siap melayani Anda",
  },
  {
    icon: Shield,
    title: "Aman & Terpercaya",
    description: "Menjaga keamanan perbatasan NKRI",
  },
]

export function HeroBanner() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    {
      title: "Selamat Datang di PLBN Napan",
      subtitle: "Pos Lintas Batas Negara",
      description: "Melayani dengan Integritas, Menjaga Perbatasan Negara Kesatuan Republik Indonesia",
    },
    {
      title: "Pelayanan Perlintasan Terpadu",
      subtitle: "One Stop Service",
      description: "Layanan Imigrasi, Bea Cukai, Karantina Kesehatan, dan BKHIT dalam satu lokasi",
    },
    {
      title: "Gerbang Indonesia - Timor Leste",
      subtitle: "Kawasan Perbatasan TTU",
      description: "Menghubungkan masyarakat perbatasan dengan pelayanan publik yang prima",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [slides.length])

  return (
    <section className="relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/95 to-accent">
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 py-16 md:py-24 lg:py-32">
        <div className="max-w-4xl mx-auto text-center text-primary-foreground">
          {/* Slide Content */}
          <div className="min-h-[200px] flex flex-col items-center justify-center">
            {slides.map((slide, index) => (
              <div
                key={index}
                className={cn(
                  "absolute transition-all duration-500 ease-in-out",
                  index === currentSlide
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-4 pointer-events-none"
                )}
              >
                <div className="inline-block px-4 py-1.5 rounded-full bg-white/10 backdrop-blur text-sm font-medium mb-6">
                  {slide.subtitle}
                </div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance">
                  {slide.title}
                </h1>
                <p className="text-lg md:text-xl text-primary-foreground/90 max-w-2xl mx-auto text-pretty">
                  {slide.description}
                </p>
              </div>
            ))}
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center gap-2 mt-8 mb-8">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={cn(
                  "w-2 h-2 rounded-full transition-all duration-300",
                  index === currentSlide
                    ? "w-8 bg-white"
                    : "bg-white/40 hover:bg-white/60"
                )}
                aria-label={`Slide ${index + 1}`}
              />
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
            <Button
              asChild
              size="lg"
              className="bg-white text-primary hover:bg-white/90 shadow-lg group"
            >
              <Link href="/alur-pelayanan">
                Lihat Alur Pelayanan
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 hover:text-white"
            >
              <Link href="/standar-operasional">
                Standar Operasional
              </Link>
            </Button>
          </div>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-16 max-w-5xl mx-auto">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur rounded-xl p-4 md:p-6 text-primary-foreground text-center transition-all duration-300 hover:bg-white/20 hover:scale-105"
            >
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-white/10 mb-3">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-sm md:text-base mb-1">{feature.title}</h3>
              <p className="text-xs md:text-sm text-primary-foreground/80">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Wave Decoration */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-auto"
          preserveAspectRatio="none"
        >
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0V120Z"
            className="fill-background"
          />
        </svg>
      </div>
    </section>
  )
}
