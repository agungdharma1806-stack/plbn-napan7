"use client"

import Image from "next/image"
import { useState } from "react"
import { ZoomIn } from "lucide-react"
import { cn } from "@/lib/utils"
import { Lightbox } from "@/components/lightbox"

interface ServiceCardProps {
  title: string
  description: string
  imageSrc: string
  imageAlt: string
  images?: { src: string; alt: string }[]
}

export function ServiceCard({ title, description, imageSrc, imageAlt, images }: ServiceCardProps) {
  const [isLightboxOpen, setIsLightboxOpen] = useState(false)
  const [currentIndex, setCurrentIndex] = useState(0)

  const handleOpen = () => {
    setIsLightboxOpen(true)
  }

  const handleNavigate = (index: number) => {
    setCurrentIndex(index)
  }

  return (
    <>
      <div
        className={cn(
          "group relative bg-card rounded-xl overflow-hidden shadow-md",
          "border border-border/50 transition-all duration-300",
          "hover:shadow-xl hover:border-primary/30 hover:-translate-y-1"
        )}
      >
        {/* Image Container */}
        <div 
          className="relative aspect-[4/3] overflow-hidden cursor-pointer"
          onClick={handleOpen}
        >
          <Image
            src={imageSrc}
            alt={imageAlt}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 text-primary font-medium text-sm">
              <ZoomIn className="h-4 w-4" />
              <span>Klik untuk memperbesar</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 md:p-5">
          <h3 className="font-semibold text-lg text-foreground mb-2 line-clamp-2">
            {title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {description}
          </p>
        </div>
      </div>

      {/* Lightbox */}
      <Lightbox
        isOpen={isLightboxOpen}
        onClose={() => setIsLightboxOpen(false)}
        imageSrc={imageSrc}
        imageAlt={imageAlt}
        images={images}
        currentIndex={currentIndex}
        onNavigate={handleNavigate}
      />
    </>
  )
}
