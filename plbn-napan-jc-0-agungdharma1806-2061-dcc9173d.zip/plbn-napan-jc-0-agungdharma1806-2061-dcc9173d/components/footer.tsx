import Link from "next/link"
import { Shield, MapPin, Phone, Mail, Facebook, Instagram, Twitter, Youtube } from "lucide-react"

const quickLinks = [
  { href: "/", label: "Beranda" },
  { href: "/standar-operasional", label: "Standar Operasional" },
  { href: "/alur-pelayanan", label: "Alur Pelayanan" },
  { href: "/layanan-pengaduan", label: "Layanan Pengaduan" },
  { href: "/kontak", label: "Kontak" },
]

const relatedLinks = [
  { href: "https://www.bnpp.go.id", label: "BNPP RI" },
  { href: "https://www.imigrasi.go.id", label: "Dirjen Imigrasi" },
  { href: "https://www.beacukai.go.id", label: "Bea Cukai" },
  { href: "https://karantina.pertanian.go.id", label: "Karantina Pertanian" },
]

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/10 backdrop-blur">
                <Shield className="h-6 w-6" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold">PLBN NAPAN</span>
                <span className="text-xs text-primary-foreground/70">Pos Lintas Batas Negara</span>
              </div>
            </div>
            <p className="text-sm text-primary-foreground/80 leading-relaxed">
              Melayani dengan Integritas, Menjaga Perbatasan Negara Kesatuan Republik Indonesia
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">Menu Utama</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link 
                    href={link.href}
                    className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-200"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Related Links */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">Tautan Terkait</h3>
            <ul className="space-y-2">
              {relatedLinks.map((link) => (
                <li key={link.href}>
                  <a 
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider">Hubungi Kami</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 shrink-0" />
                <span className="text-sm text-primary-foreground/80">
                  Desa Napan, Kec. Bikomi Utara, Kab. Timor Tengah Utara, NTT
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 shrink-0" />
                <span className="text-sm text-primary-foreground/80">(0388) 21234</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 shrink-0" />
                <span className="text-sm text-primary-foreground/80">plbn.napan@bnpp.go.id</span>
              </li>
            </ul>

            {/* Social Media */}
            <div className="pt-4">
              <h4 className="text-sm font-semibold mb-3">Media Sosial</h4>
              <div className="flex gap-3">
                <a 
                  href="#" 
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-200"
                  aria-label="Facebook"
                >
                  <Facebook className="h-4 w-4" />
                </a>
                <a 
                  href="#" 
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-200"
                  aria-label="Instagram"
                >
                  <Instagram className="h-4 w-4" />
                </a>
                <a 
                  href="#" 
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-200"
                  aria-label="Twitter"
                >
                  <Twitter className="h-4 w-4" />
                </a>
                <a 
                  href="#" 
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-200"
                  aria-label="Youtube"
                >
                  <Youtube className="h-4 w-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-primary-foreground/70">
            <p>&copy; {new Date().getFullYear()} PLBN Napan. Hak Cipta Dilindungi.</p>
            <p>Badan Nasional Pengelola Perbatasan (BNPP)</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
